#include "Graph.h"
#include <algorithm>
#include <fstream>
#include <map>
#include "Incidencia.h"
#include <iostream>
#include <sstream>
#include <queue>
#include <vector>
#include <tuple>



Graph::Graph() {
  adjList.clear();
}

Graph::Graph(std::ifstream &input, std::vector<Incidencia> &nodosOrigen) {
   std::string mes, dia, horas,ip_origen, ip_destino, peso, razon, error1, error2, error3,
    error4, error5, error6;  
  
  std::vector<Incidencia> incidencias;
  std::string line;
  int i = 0;

  while (std::getline(input, line)) {
    if (i == 0) {
      std::vector<int> result;
      split(line, result);
      numNodes = result[0];
      numEdges = result[1];

      // Reservar memoria para renglones de la lista de adyacencia
      // Nodos son uno basados (renglon 0 no sera usado)
      adjList.resize(numNodes + 1);
      // Declarar un lista vacia para cada renglon y se almacena en el vector
      for (int k = 1; k <= numNodes; k++) {

        LinkedList<std::pair<Incidencia, int>> tmpList; // con Ipinfo
        
      }
    }
      
    //Guardar nodos
    else if (i <= numNodes){
      Incidencia nodoOrigen;
      nodoOrigen.setIpValue(line, 0);
      nodosOrigen.push_back(nodoOrigen);
    }
      
    // Guardar incidencias
    else if(i <= numNodes + numEdges){
      std::istringstream ss(line);
      // Obtenemos los datos que estan separados por espacios
      ss >> mes >> dia >> horas >> ip_origen >> ip_destino >> peso >> error1 >> error2 >> error3 >> error4 >>
          error5 >> error6;

      //Incidencia temporal
      Incidencia IncidenciaTemp(mes,dia,horas,ip_origen,ip_destino, peso, razon);
      IncidenciaTemp.cambiarFormato(ip_origen, ip_destino, peso);
      //Agregar a vector incidencias
      incidencias.push_back(IncidenciaTemp);
    }
    i++;
  }

  // Ordenar nodos
  std::sort(nodosOrigen.begin(), nodosOrigen.end());

  for (int j = 0; j < (int)nodosOrigen.size(); j++) {
    nodosOrdenados[j + 1] = nodosOrigen[j].getIpOrigen();
  }


  //Imprimir valores de map
//   for (const auto& pair : nodosOrdenados) {
//   std::cout << "Key: " << pair.first << ", Value: " << pair.second << std::endl;
// }
  
  // Construir lista de adyacencia - -- - -- -- - 
  std::sort(incidencias.begin(), incidencias.end());
  
  int x=0;
  int numV = 0;
  std::string nombre = nodosOrigen[0].getIpOrigen();
  int nodoAct = 0;

  // Rellenar lista
  for(int i = 1; i <= numEdges; i++) {
    std::string nombre_temp = nombre;
    nombre = incidencias[i-1].getIpOrigen();
    std::string accesado = incidencias[i-1].getIpDestino();

    if(nodosOrigen[x].getIpOrigen() == accesado){
      std::cout<< "If en " << x+1;
    }

    
    // Cambio de nodo?
    if(nombre_temp != nombre){
      nodoAct++;
    
      nodosOrigen[x].setNumVecinos(numV);
      x++;
      numV = 0;
      nodosOrigen[x].salidas.clear();
      }
    
      
    int nodoU = x;
    Incidencia nodoV = incidencias[i-1]; // Guardar incidencia
    int weight = incidencias[i-1].getPeso();

    // grafo dirigido agregar aristas (u,v) unicamente 
    // Insertar incidencia(ipinfo) y peso
    adjList[nodoU].addLast(std::make_pair(nodoV, weight));
    numV++;
    // std::cout<< accesado << std::endl;
    if(accesado != "000.000.000.000")
      nodosOrigen[nodoAct].salidas.push_back(accesado);

  //   Incidencia& nodoUIncidencia = nodosOrigen[nodoU];
  // // Agregar la dirección IP accesada al atributo 'salidas' de nodoUIncidencia
  //   nodoUIncidencia.salidas.push_back(accesado);
    // int nodo = -1;

    // Búsqueda inversa en el mapa nodosOrdenados
    // for (const auto& pair : nodosOrdenados) {
    //   if (pair.second == accesado) {
    //     nodo = pair.first;
    //     break;
    //   }
    // }

    // std::cout<< nodo << std::endl;
    
  }

  this->countEntries(nodosOrigen);
  // std::cout<<"Entradas a primer nodo: " << adjList[0].getHead()->data.first.getEntries() << std::endl;  
  // std::cout<<"Entradas a primer nodo: " << nodosOrigen[0].getEntries()<< std::endl;

  
}

Graph::~Graph() {
  adjList.clear();
}

int Graph::getNumEdges(){
  return numEdges;
}

int Graph::getNumNodes(){
  return numNodes;
}

std::map<int, std::string> Graph::getNodosOrdenados(){
  return nodosOrdenados;
}


std::vector<LinkedList<std::pair<Incidencia, int>>>Graph::getAdjList(){
  return adjList;
}

// Obtener orden de nodo
int Graph::getNodeOrder(const std::string &node){
  for(const auto &map : nodosOrdenados) {
    if(map.second == node) {
      return map.first;
    }
  }
  return -1; // Si el nodo no se encuentra en el map
}

void Graph::split(std::string line, std::vector<int> & res) {
    size_t strPos = line.find(" ");
    size_t lastPos = 0;
    while (strPos != std::string::npos) {
      res.push_back(stoi(line.substr(lastPos, strPos - lastPos)));
      lastPos = strPos + 1;
      strPos = line.find(" ", lastPos);
    }
    res.push_back(stoi(line.substr(lastPos, line.size() - lastPos)));
}

void Graph::countEntries(std::vector<Incidencia> &nodosOrigen){
  
  // Recorrer la lista de adyacencia y contar las conexiones entrantes para cada IP
    for (int nodeU = 1; nodeU <= numNodes; nodeU++) {
      std::string ipNodo = nodosOrdenados.at(nodeU);

      // Contar coincidencias de la IP destino en nodosOrigen
      int count = std::count_if(nodosOrigen.begin(), nodosOrigen.end(), [ipNodo](const Incidencia& incidencia) {
        return incidencia.getIpDestino() == ipNodo; });

      // std::cout<< count << std::endl;

      nodosOrigen[nodeU].setEntries(count);
      

      // NodeLinkedList<std::pair<Incidencia, int>>* ptr = adjList[nodeU].getHead();
      // while (ptr != nullptr) {
      //   std::string ipDestino = ptr->data.first.getIpDestino();



      //   count++;
      //   std::cout<< count << std::endl;

      //   // aumentar contador
      //   ptr->data.first.setEntries(count);
      //   // std::cout<<ptr->data.first.getEntries();
      //   ptr = ptr->next;
      // }
      // ptr->data.first.setEntries(count)
      
    }
}

void Graph::print() {
  std::cout << "numNode: " << numNodes << std::endl;
  std::cout << "numEdges: " << numEdges << std::endl;
  std::cout << "Adjacency List" << std::endl;
  for (int nodeU = 0; nodeU <= numNodes; nodeU++) {
    std::cout << "vertex " << nodeU << ": ";
    NodeLinkedList<std::pair<Incidencia, int>> *ptr = adjList[nodeU].getHead();
    while (ptr != nullptr) {
      std::pair<Incidencia, int> par = ptr->data;
      std::cout << "{" << par.first.getIpOrigen() << "," << par.second << "} ";
      ptr = ptr->next;
    }
    std::cout << std::endl;
  }
}


