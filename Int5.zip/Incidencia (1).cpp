#include "Incidencia.h"
#include <math.h>
#include <sstream>

// Constructor default
Incidencia::Incidencia(){
  mes = "";
  dia = "";
  horas = "0";
  ip_origen = "";
  ip_origen_value = 0;
  puerto_origen = "";
  ip_destino = "";
  puerto_destino =  "";
  peso_inicial = "";
  peso = 0;
  razon = "";
}

// Constructor
Incidencia::Incidencia(std::string _mes, std::string _dia, std::string _horas, std::string _ip_origen, std::string _ip_destino, std::string _peso, std::string _razon){

  mes = _mes;
  dia = _dia;
  horas = _horas;
  ip_origen = _ip_origen;
  // puerto_origen = _puerto_origen;
  ip_destino = _ip_destino;
  // puerto_destino = _puerto_destino;
  peso_inicial = _peso;
  razon = _razon;
  ip_destino_value = 0;
}

Incidencia::~Incidencia(){
  
}

// Setters
void Incidencia::setDia(std::string _dia) { dia = _dia; }
void Incidencia::setHoras(std::string _horas) { horas = _horas; }
void Incidencia::setIpOrigen(std::string _ip_origen) { ip_origen = _ip_origen; }
void Incidencia::setIpOrigenValue(unsigned int _ip_origen_value) { ip_origen_value = _ip_origen_value; }
void Incidencia::setIpDestino(std::string _ip_destino) { ip_destino = _ip_destino; }
void Incidencia::setPuertoOrigen(std::string _puerto_origen) { puerto_origen = _puerto_origen; }
void Incidencia::setPuertoDestino(std::string _puerto_destino) { puerto_destino = _puerto_destino; }
void Incidencia::setMes(std::string _mes) { mes = _mes; }
void Incidencia::setPeso(int _peso) { peso = _peso; }
void Incidencia::setNumVecinos(int _num_vecinos) {  num_vecinos = _num_vecinos; }
void Incidencia::setEntries(int _entries) {  entries = _entries; }

//getters
unsigned int Incidencia::getIpOrigenValue(){ return ip_origen_value; }
std::string Incidencia::getIpOrigen(){ return ip_origen; }
std::string Incidencia::getIpDestino() const { return ip_destino; }
std::string Incidencia::getPuertoOrigen(){return puerto_origen; }
std::string Incidencia::getPuertoDestino() {return puerto_destino; }
std::string Incidencia::getPesoInicial(){ return peso_inicial; }
int Incidencia::getNumVecinos(){ return num_vecinos; }
int Incidencia::getPeso(){ return peso; }
int Incidencia::getEntries(){ return entries; }


// Setter con calculo de valor total de Ip
void Incidencia::setIpValue(std::string _ip_value, int n) { 
  
  std::string octeto;

  std::stringstream octetos(_ip_value);
  int cont = 3;
  unsigned int totalValue = 0;

  for(int i=0; i <4; i++) {
    // Separar octetos de direccion ip por delimitador "."
    getline(octetos, octeto, '.');
    
    // Convertir a int 
    int num = stoi(octeto);


    // Elevar valor del octeto a potencia correspondiente
    num *= pow(256, cont);
    // Agregar a suma total
    totalValue += num;
    cont--;
  }

  if(n == 0){
    ///////
    this->setIpOrigenValue(totalValue);
    ip_origen = _ip_value;
  }
  else{
    ip_destino_value = totalValue;
    ip_destino = _ip_value;
  }
    
}

// Separa  ip-puerto y setea peso en int
void Incidencia::cambiarFormato(std::string ip_puerto_origen, std::string ip_puerto_destino, std::string pesostr){


  std::string ip_og, puerto_og, ip_dst,  puerto_dst;
  
  // Separando puerto de ip
  std::stringstream ssip_puerto_og(ip_puerto_origen);
  std::stringstream ssip_puerto_dst(ip_puerto_destino);

  getline(ssip_puerto_og, ip_og, ':');
  getline(ssip_puerto_og, puerto_og, ':');
  getline(ssip_puerto_dst, ip_dst, ':');
  getline(ssip_puerto_dst, puerto_dst, ':');
  
  //Setear puerto e ip
  this->setIpOrigen(ip_og);
  this->setPuertoOrigen(puerto_og);
  this->setIpDestino(ip_dst);
  this->setPuertoDestino(puerto_dst);

  // Transformar y setear ip
  this->setIpValue(ip_og, 0);
  this->setIpValue(ip_dst, 1);

  this->setPeso(stoi(pesostr));
}





// Comparacion de Registro por direccion ip
bool Incidencia::operator==(const Incidencia &other) {
  return this->ip_origen_value == other.ip_origen_value;
}

bool Incidencia::operator!=(const Incidencia &other) {
  return this->ip_origen_value != other.ip_origen_value;
}

bool Incidencia::operator>=(const Incidencia &other) {
  return this->ip_origen_value >= other.ip_origen_value;
}

bool Incidencia::operator<=(const Incidencia &other) {
  return this->ip_origen_value <= other.ip_origen_value;
}

bool Incidencia::operator>(const Incidencia &other) {
  return this->ip_origen_value > other.ip_origen_value;
}

bool Incidencia::operator<(const Incidencia &other) {
  return this->ip_origen_value < other.ip_origen_value;
}